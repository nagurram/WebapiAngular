﻿namespace LSDataApi.Models
{
    public class keyvalueModel
    {
        public int Id { get; set; }
        public string keyValue { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
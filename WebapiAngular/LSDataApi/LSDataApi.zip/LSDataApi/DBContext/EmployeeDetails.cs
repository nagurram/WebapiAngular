﻿namespace LSDataApi.DBContext
{
    public partial class EmployeeDetails
    {
        public int? Empid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmailId { get; set; }
        public string Address { get; set; }
    }
}
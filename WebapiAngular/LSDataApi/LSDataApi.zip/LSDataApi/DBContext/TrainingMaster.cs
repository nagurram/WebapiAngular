﻿namespace LSDataApi.DBContext
{
    public partial class TrainingMaster
    {
        public int TrianingId { get; set; }
        public string Details { get; set; }
    }
}
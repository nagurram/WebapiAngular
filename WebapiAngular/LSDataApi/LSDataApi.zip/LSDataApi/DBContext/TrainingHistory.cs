﻿namespace LSDataApi.DBContext
{
    public partial class TrainingHistory
    {
        public int? Userid { get; set; }
        public int? YearNo { get; set; }
        public int? TrainigId { get; set; }
    }
}
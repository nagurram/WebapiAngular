﻿namespace LsDataApi.Common
{
    public static class Constants
    {
        public const string Email = "email";
        public const string UserId = "userid";
        public const string FirstName = "FirstName";
        public const string LastName = "LastName";
        public const string LoggedOn = "LoggedOn";
    }
}